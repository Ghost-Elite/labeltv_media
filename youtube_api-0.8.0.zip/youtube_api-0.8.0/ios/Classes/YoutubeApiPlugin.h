#import <Flutter/Flutter.h>

@interface YoutubeApiPlugin : NSObject<FlutterPlugin>
@end
